package com.cg.onlineflatrental.service;

public class TenantService {

}
