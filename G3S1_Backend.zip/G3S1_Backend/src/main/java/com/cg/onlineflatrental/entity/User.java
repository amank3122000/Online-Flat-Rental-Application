package com.cg.onlineflatrental.entity;

public class User {

}
