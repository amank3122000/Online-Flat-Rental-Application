package com.cg.onlineflatrental.entity;

public class Landlord {

}
