package com.cg.onlineflatrental.controller;

public class UserController {

}
