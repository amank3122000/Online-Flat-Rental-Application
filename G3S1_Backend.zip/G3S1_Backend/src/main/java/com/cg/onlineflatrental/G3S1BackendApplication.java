package com.cg.onlineflatrental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G3S1BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(G3S1BackendApplication.class, args);
	}

}
