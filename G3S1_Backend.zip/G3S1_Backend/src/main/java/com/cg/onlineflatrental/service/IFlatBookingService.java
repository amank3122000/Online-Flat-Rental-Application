package com.cg.onlineflatrental.service;

public interface IFlatBookingService {

}
