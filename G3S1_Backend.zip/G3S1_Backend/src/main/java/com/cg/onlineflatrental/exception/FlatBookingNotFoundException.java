package com.cg.onlineflatrental.exception;

public class FlatBookingNotFoundException {

}
