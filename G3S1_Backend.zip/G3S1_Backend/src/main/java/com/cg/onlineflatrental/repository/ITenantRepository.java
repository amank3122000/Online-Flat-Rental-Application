package com.cg.onlineflatrental.repository;

public interface ITenantRepository {

}
