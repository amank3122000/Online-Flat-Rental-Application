package com.cg.onlineflatrental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G3S1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
